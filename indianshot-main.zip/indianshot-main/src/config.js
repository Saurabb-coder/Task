export const apiKey = "YOUR_FLIKR_API_KEY";
